﻿
namespace QuickStart
{
    class Program
    {
        static void Main()
        {
            FileAccess.ShowFileAccess();
            Sockets.ShowSockets();
        }
    }
}
